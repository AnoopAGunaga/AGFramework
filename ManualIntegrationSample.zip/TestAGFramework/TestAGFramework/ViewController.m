//
//  ViewController.m
//  TestAGFramework
//
//  Created by Anoop Gunaga on 24/11/16.
//  Copyright © 2016 Robosoft. All rights reserved.
//

#import "ViewController.h"


@interface ViewController ()

@property (weak, nonatomic) IBOutlet UILabel *launchCountInfoLabel;
@property (weak, nonatomic) IBOutlet UILabel *usageInfoLabel;

@end

@implementation ViewController

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - View life cycle

- (void)viewDidLoad {
    [super viewDidLoad];
}

-(void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];
    
    _launchCountInfoLabel.text = [NSString stringWithFormat:@"App Launch Count : %ld",[AGFramework appLaunchCount]];
    _usageInfoLabel.text = [NSString stringWithFormat:@"App Usage Info : %lf",[AGFramework appUsageInfo]];
}

#pragma mark - Button actions

- (IBAction)didTapPostAppAnalytics:(id)sender {
    [AGFrameworkEvent postEventInfo:@{@"AppVersion":@"1.0"}];
}

@end
